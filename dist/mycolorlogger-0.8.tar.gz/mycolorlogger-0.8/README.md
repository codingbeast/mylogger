###  Example
from Mylogger import log  
log.logger.debug("Debug message")  
log.logger.info("Information message")  
log.logger.warning("Warning message")  
log.logger.error("Error message")  
log.logger.critical("Critical message")  